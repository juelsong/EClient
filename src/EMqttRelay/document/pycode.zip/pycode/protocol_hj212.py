from crc import crc_hj212_calc


# 将设备数据打包成HJ212协议
def device_data_to_hj212_packet(device, publish_k, data_dict):
    # a34001:   TSP
    # a34002:   PM10
    # a34004:   PM2.5
    # a50001:   噪声
    # a01001:   温度
    # a01002:   湿度
    # a01006:   气压
    # a01007:   风速
    # a01008:   风向
    if publish_k != 0:
        cpm_min = int(round((data_dict['tsp_min'] / publish_k) / 1000, 3))
        cpm_max = int(round((data_dict['tsp_max'] / publish_k) / 1000, 3))
        cpm_average = int(round((data_dict['tsp_average'] / publish_k) / 1000, 3))
    else:
        cpm_min = 0
        cpm_max = 0
        cpm_average = 0

    tsp_min = round(cpm_min * publish_k, 3)
    tsp_max = round(cpm_max * publish_k, 3)
    tsp_average = round(cpm_average * publish_k, 3)

    if cpm_min >= 1000 or cpm_max >= 1000 or cpm_average >= 1000:
        return ''
    elif tsp_min >= 1 or tsp_max >= 1 or tsp_average >= 1:
        return ''

    hj212_payload_string = 'QN=%04d%02d%02d%02d%02d%02d%03d;' \
                   'ST=22;' \
                   'CN=2051;' \
                   'PW=123456;' \
                   'MN=%s;' \
                   'CP=&&DataTime=%04d%02d%02d%02d%02d%02d;' \
                   'a34001-Avg=%.3f,a34001-Max=%.3f,a34001-Min=%.3f,a34001-Flag=%s;' \
                   'a01007-Avg=%.1f,a01007-Max=%.1f,a01007-Min=%.1f,a01007-Flag=%s;' \
                   'a01008-Avg=%d,a01008-Max=%d,a01008-Min=%d,a01008-Flag=%s;' \
                   'a01001-Avg=%.1f,a01001-Max=%.1f,a01001-Min=%.1f,a01001-Flag=%s;' \
                   'a01002-Avg=%.1f,a01002-Max=%.1f,a01002-Min=%.1f,a01002-Flag=%s;' \
                   'a01006-Avg=%.2f,a01006-Max=%.2f,a01006-Min=%.2f,a01006-Flag=%s;' \
                   'a50001-Avg=%.1f,a50001-Max=%.1f,a50001-Min=%.1f,a50001-Flag=%s;' \
                   'cpm-Avg=%d,cpm-Max=%d,cpm-Min=%d,cpm-Flag=%s;' \
                   '&&' % \
                   (
                        data_dict['update_time'].year,
                        data_dict['update_time'].month,
                        data_dict['update_time'].day,
                        data_dict['update_time'].hour,
                        data_dict['update_time'].minute,
                        data_dict['update_time'].second,
                        0,
                        device['mn'],
                        data_dict['update_time'].year,
                        data_dict['update_time'].month,
                        data_dict['update_time'].day,
                        data_dict['update_time'].hour,
                        data_dict['update_time'].minute,
                        data_dict['update_time'].second,
                        tsp_average,
                        tsp_max,
                        tsp_min,
                        'N' if tsp_average != 0 else 'F',
                        round(data_dict['wind_speed_average'] / 10, 1),
                        round(data_dict['wind_speed_max'] / 10, 1),
                        round(data_dict['wind_speed_min'] / 10, 1),
                        'N',
                        round(data_dict['wind_direction_average'] / 10, 1),
                        round(data_dict['wind_direction_max'] / 10, 1),
                        round(data_dict['wind_direction_min'] / 10, 1),
                        'N',
                        round(data_dict['temperature_average'] / 10, 1),
                        round(data_dict['temperature_max'] / 10, 1),
                        round(data_dict['temperature_min'] / 10, 1),
                        'N',
                        round(data_dict['humidity_average'] / 10, 1),
                        round(data_dict['humidity_max'] / 10, 1),
                        round(data_dict['humidity_min'] / 10, 1),
                        'N',
                        round(data_dict['pre_avg'] / 100, 2),
                        round(data_dict['pre_max'] / 100, 2),
                        round(data_dict['pre_min'] / 100, 2),
                        'N' if data_dict['pre_avg'] != 0 else 'F',
                        round(data_dict['noise_average'] / 10, 1),
                        round(data_dict['noise_max'] / 10, 1),
                        round(data_dict['noise_min'] / 10, 1),
                        'N' if data_dict['noise_average'] != 0 else 'F',
                        cpm_average,
                        cpm_max,
                        cpm_min,
                        'N' if cpm_average != 0 else 'F'
                   )

    hj212_payload_string_length = len(hj212_payload_string)

    hj212_string = ('##%04d' % hj212_payload_string_length) + hj212_payload_string

    # 负载数据数组
    hj212_payload_bytes = hj212_payload_string.encode('gbk')

    crc_hj212 = crc_hj212_calc(hj212_payload_bytes, len(hj212_payload_bytes))
    crc_hj212_bytes = crc_hj212.to_bytes(2, byteorder='big')

    hj212_string += '%02X%02X' % (crc_hj212_bytes[0], crc_hj212_bytes[1])
    hj212_string += bytes.fromhex('0D0A').decode('gbk')

    # packet = hj212_string.encode('gbk')                            # HJ212 协议内容

    # return packet

    return hj212_string
