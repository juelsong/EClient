import json
import ssl
import time
import datetime
import http.client
import database_api
from paho.mqtt import client as mqtt_client

from config import broker_address, port, topic, username, password
from config import db_connect_command
from config import db_api_device_table_name, db_base_device_table_name
from config import db_minute_data_table_name

from protocol_hj212 import device_data_to_hj212_packet


wind_speed_level_table = [
    {'level': 0, 'max': 0.2},
    {'level': 1, 'max': 1.5},
    {'level': 2, 'max': 3.3},
    {'level': 3, 'max': 5.4},
    {'level': 4, 'max': 7.9},
    {'level': 5, 'max': 10.7},
    {'level': 6, 'max': 13.8},
    {'level': 7, 'max': 17.1},
    {'level': 8, 'max': 20.7},
    {'level': 9, 'max': 24.4},
    {'level': 10, 'max': 28.4},
    {'level': 11, 'max': 32.6},
    {'level': 12, 'max': 10000},  # 按接口文档要求，以上全部定为12级
]


def get_wind_speed_level(wind_speed_value):
    for level in wind_speed_level_table:
        if wind_speed_value < level['max']:
            return level['level']

    return 0  # 无匹配项默认输出0


def wind_direction_level(direction_value):
    # 第三方接口数据
    if 11.25 < direction_value <= 33.75:
        level_value = '北东北'
        level_int = 2
    elif 33.75 < direction_value <= 56.25:
        level_value = '东北'
        level_int = 3
    elif 56.25 < direction_value <= 78.75:
        level_value = '东东北'
        level_int = 4
    elif 78.75 < direction_value <= 101.25:
        level_value = '东'
        level_int = 5
    elif 101.25 < direction_value <= 123.75:
        level_value = '东东南'
        level_int = 6
    elif 123.75 < direction_value <= 146.25:
        level_value = '东南'
        level_int = 7
    elif 146.25 < direction_value <= 168.75:
        level_value = '南东南'
        level_int = 8
    elif 168.75 < direction_value <= 191.25:
        level_value = '南'
        level_int = 9
    elif 191.25 < direction_value <= 213.75:
        level_value = '南西南'
        level_int = 10
    elif 213.75 < direction_value <= 236.25:
        level_value = '西南'
        level_int = 11
    elif 236.25 < direction_value <= 258.75:
        level_value = '西西南'
        level_int = 12
    elif 258.75 < direction_value <= 281.25:
        level_value = '西'
        level_int = 13
    elif 281.25 < direction_value <= 303.75:
        level_value = '西西北'
        level_int = 14
    elif 303.75 < direction_value <= 326.25:
        level_value = '西北'
        level_int = 15
    elif 326.25 < direction_value <= 348.75:
        level_value = '北西北'
        level_int = 16
    else:
        level_value = '北'
        level_int = 1

    return level_value


# 当接收到MQTT消息时，这个回调函数会被调用
def on_message(client, userdata, message):
    print(f"Received message: {message.payload.decode()}")


def post_data(update_time):
    connection_result = database_api.database_connect(db_connect_command)

    data_start_time_string = (update_time - datetime.timedelta(minutes=3)).strftime('%Y-%m-%d %H:%M:00')
    data_end_time_string = (update_time - datetime.timedelta(minutes=2)).strftime('%Y-%m-%d %H:%M:00')

    if connection_result.is_connected is not True:
        print('[%s] database connect failed!' % datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
        return

    devices_select_result = database_api.database_select(
        connection_result.connection,
        db_api_device_table_name,
        '*',
        'WHERE is_transfer>0 '
    )

    for device in devices_select_result.data_list:
        try:
            # 创建一个客户端实例
            client = mqtt_client.Client(client_id=device['mn'], clean_session=False)

            # 设置不验证SSL证书
            client.tls_set(
                ca_certs=None,  # 不指定CA证书
                certfile=None,  # 不指定客户端证书
                keyfile=None,  # 不指定客户端密钥
                cert_reqs=ssl.CERT_NONE,  # 跳过证书验证
                tls_version=ssl.PROTOCOL_TLS,  # 使用的SSL/TLS版本
                ciphers=None  # 默认加密算法
            )

            # 禁用主机名检查
            client.tls_insecure_set(True)

            # 设置用户名和密码
            client.username_pw_set(username, password)

            # 设置消息回调函数
            client.on_message = on_message

            # 连接到MQTT代理
            client.connect(broker_address, port)

            client.subscribe(topic)

            data_select_result = database_api.database_select(
                connection_result.connection,
                db_minute_data_table_name,
                '*',
                'WHERE device_of_data=%d '
                'AND is_valid_data=True '
                'AND update_time >= \'%s\' AND update_time < \'%s\'' % (
                    device['device_id'],
                    data_start_time_string,
                    data_end_time_string
                )
            )

            if len(data_select_result.data_list) > 0:
                front_k_select_result = database_api.database_select(
                    connection_result.connection,
                    db_base_device_table_name,
                    'dust_k_frontend',
                    'WHERE device_id=%d ' % device['device_id']
                )

                if len(front_k_select_result.data_list) > 0:
                    publish_k = front_k_select_result.data_list[0]['dust_k_frontend']

                    data_of_device = data_select_result.data_list[0]

                    hj212_string = device_data_to_hj212_packet(device, publish_k, data_of_device)

                    # print(hj212_string)

                    return_value = client.publish(topic, hj212_string)

                    print('[%s]' % device['device_id'] + str(return_value))

            client.disconnect()
        except Exception as e:
            print(e)

    database_api.database_disconnect(connection_result.connection)
