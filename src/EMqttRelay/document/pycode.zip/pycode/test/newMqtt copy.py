import paho.mqtt.client as mqtt
import ssl
import socket
import threading
import time

# 创建一个事件对象，用于通知线程退出
exit_event = threading.Event()

# MQTT服务器地址和端口
mqtt_server = "61.171.88.34"
mqtt_port = 18883

# MQTT客户端配置
mqtt_username = "monitor_pole"
mqtt_password = "Monitor.2024#Pole"
mqtt_topic = "monitor/pole/tcpdata"
mqtt_clients = {}

# TCP服务器配置
tcp_ip = "0.0.0.0"
tcp_port = 40003

# MQTT回调函数
def on_connect(client, userdata, flags, rc):
    if rc == 0:
        print("Connected to MQTT Broker!")
    else:
        print("Failed to connect, return code %d\n", rc)

# TCP服务器处理函数
def handle_client(clientsocket, clientaddr):
    try:
        print('Connection from', clientaddr)
        while True:
            data = clientsocket.recv(1024)
            if not data:
                break
            data_str = data.decode()
            print('Received from', clientaddr, data_str)
            # 解析消息以获取 client_id
            client_id = parse_mn(data_str)  # 你需要根据实际情况解析消息来获取 client_id
            if client_id:
                publish_to_mqtt(client_id, data_str)
    except Exception as e:
        print(f"Exception occurred: {e}")
    finally:
        clientsocket.close()
        print(f"Client disconnected: {clientaddr}")

def publish_to_mqtt(client_id, data):
    if client_id not in mqtt_clients:
        # 创建新的MQTT客户端实例
        client = mqtt.Client(client_id=client_id)
        client.username_pw_set(mqtt_username, mqtt_password)
        client.tls_set(ca_certs=None, certfile=None, keyfile=None, cert_reqs=ssl.CERT_NONE, tls_version=ssl.PROTOCOL_TLS, ciphers=None)
        client.tls_insecure_set(True)
        client.on_connect = on_connect        
        client.connect(mqtt_server, mqtt_port, 60)
        client.loop_start()
        mqtt_clients[client_id] = client
    else:
        client = mqtt_clients[client_id]

    client.publish(mqtt_topic, data)
    print(f"Data sent to MQTT by {client_id}: {data}")

# 解析MN字段并返回clientId
def parse_mn(data):
    parts = data.split(';')
    for part in parts:
        if part.startswith('MN='):
            return part[3:]
    return None

# TCP服务器线程
def tcp_server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    
    server_socket.bind(('', tcp_port))
    server_socket.listen(5)
    print(f"TCP server listening on {tcp_ip}:{tcp_port}")

    try:
        while not exit_event.is_set():
            clientsocket, clientaddr = server_socket.accept()
            client_thread = threading.Thread(target=handle_client, args=(clientsocket, clientaddr))
            client_thread.start()
    except Exception as e:
        print(f"TCP server exception: {e}")
    finally:
        server_socket.close()
        print("TCP server socket closed.")

# 主函数
def main():
    # 创建并启动TCP服务器线程
    tcp_server_thread = threading.Thread(target=tcp_server)
    tcp_server_thread.daemon = True  # 设置为守护线程，当主线程退出时，守护线程也会退出
    tcp_server_thread.start()

    try:
        while not exit_event.is_set():
            time.sleep(1)
    except KeyboardInterrupt:
        print("Exiting...")
        exit_event.set()  # 设置退出事件

    for client in mqtt_clients.values():
        client.loop_stop()
        client.disconnect()
    # 等待TCP服务器线程结束
    tcp_server_thread.join()

if __name__ == "__main__":
    main()
