import paho.mqtt.client as mqtt
import ssl
import time

# MQTT服务器地址和端口
mqtt_server = "z8a0a8dd.ala.cn-hangzhou.emqxsl.cn"  #"127.0.0.1"
mqtt_port = 8883

# MQTT连接选项
mqtt_username = "monitor_pole"
mqtt_password = "Monitor.2024#Pole"
mqtt_topic = "monitor/pole/"

# MQTT消息
mqtt_message = "##0563QN=20241205100227000;ST=22;CN=2051;PW=123456;MN=HJZB0XH0150109;CP=&&DataTime=20241205100227;a34001-Avg=0.160,a34001-Max=0.160,a34001-Min=0.160,a34001-Flag=N;a01007-Avg=0.0,a01007-Max=0.0,a01007-Min=0.0,a01007-Flag=N;a01008-Avg=0,a01008-Max=0,a01008-Min=0,a01008-Flag=N;a01001-Avg=15.1,a01001-Max=15.2,a01001-Min=15.1,a01001-Flag=N;a01002-Avg=54.4,a01002-Max=54.5,a01002-Min=54.4,a01002-Flag=N;a01006-Avg=0.00,a01006-Max=0.00,a01006-Min=0.00,a01006-Flag=F;a50001-Avg=41.7,a50001-Max=43.1,a50001-Min=40.9,a50001-Flag=N;cpm-Avg=57,cpm-Max=57,cpm-Min=57,cpm-Flag=N;&&8701"
#"##0252ST=22;CN=2011;PW=987243;MN=HJZB0XH0150109;CP=&&DataTime=20241202165000;a34001-Avg=0.080,a34001-Flag=N;a50001-Avg=50.4,a50001-Flag=N;a01001-Avg=120.0,a01001-Flag=N;a01002-Avg=99.9,a01002-Flag=N;a01007-Avg=0.0,a01007-Flag=N;a01008-Avg=0.0,a01008-Flag=N&&DBC1"

# MQTT回调函数
def on_connect(client, userdata, flags, rc):
    if rc == 0:
        print(f"{client._client_id.decode()} Connected successfully.")
        # 订阅主题
        client.subscribe(mqtt_topic)
    else:
        print(f"{client._client_id.decode()} Connection failed with code {rc}")

def on_message(client, userdata, msg):
    print(f"{client._client_id.decode()} Received message '{msg.payload.decode()}' on topic '{msg.topic}' with QoS {msg.qos}")

# 创建发送客户端实例
sender_client = mqtt.Client(client_id="sender_client")
# 创建接收客户端实例
receiver_client = mqtt.Client(client_id="receiver_client")

# 为两个客户端设置MQTT连接选项
for client in [sender_client, receiver_client]:
    client.username_pw_set(mqtt_username, mqtt_password)
    client.tls_set(ca_certs=None, certfile=None, keyfile=None, cert_reqs=ssl.CERT_NONE, tls_version=ssl.PROTOCOL_TLS, ciphers=None)
    client.tls_insecure_set(True)
    client.on_connect = on_connect
    client.on_message = on_message

# 连接到MQTT服务器
sender_client.connect(mqtt_server, mqtt_port, 60)
receiver_client.connect(mqtt_server, mqtt_port, 60)

# 开始网络循环，并自动处理重连
sender_client.loop_start()
receiver_client.loop_start()

# 发布消息
try:
    while True:
        time.sleep(60)  # 每隔5秒发送一次消息
        sender_client.publish(mqtt_topic, mqtt_message)
        print(f"{sender_client } { mqtt_topic} send  {mqtt_message}")
except KeyboardInterrupt:
    print("Exiting...")

# 停止网络循环
sender_client.loop_stop()
receiver_client.loop_stop()

# 断开连接
sender_client.disconnect()
receiver_client.disconnect()
