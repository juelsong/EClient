import paho.mqtt.client as mqtt
import ssl
import socket
import threading
import time

# MQTT服务器地址和端口
mqtt_server = "61.171.88.34"
mqtt_port = 18883

# MQTT连接选项
mqtt_username = "monitor_pole"
mqtt_password = "Monitor.2024#Pole"
mqtt_topic = "monitor/pole/"

# 创建MQTT客户端实例
mqtt_clients = {}  # 用于存储每个MN对应的MQTT客户端

tcpClientThreads = []

# MQTT连接回调
def on_connect(client, userdata, flags, rc):
    if rc == 0:
        print(f"{client._client_id.decode()} Connected successfully.")
    else:
        print(f"{client._client_id.decode()} Connection failed with code {rc}")

# TCP服务器部分
def tcp_server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(('', 40003))
    server_socket.listen(5)
    print("TCP server listening on port 40003")

    try:
        while True:
            client_socket, addr = server_socket.accept()
            print(f"Connected by {addr}")
            client_thread = threading.Thread(target=handle_client, args=(client_socket,addr))
            client_thread.daemon = True  # 设置为守护线程
            tcpClientThreads.append(client_thread)
            client_thread.start()

    except Exception as e:
        print(f"TCP server exception: {e}")
    finally:
        server_socket.close()
        print("TCP server socket closed.")

# 处理TCP客户端连接
def handle_client(client_socket,addr):
    try:
        while True:
            data = client_socket.recv(1024)
            if not data:
                break
            data_str = data.decode()
            print(data_str)
            client_id = parse_mn(data_str)
            if client_id:
                publish_to_mqtt(client_id, data_str)
    except socket.error as e:
        print(f"Socket error: {e}")
    except Exception as e:
        print(f"Error handling client: {e}")
    finally:
        client_socket.close()
        print(f"Client disconnected: {addr}")

# 解析MN字段并返回clientId
def parse_mn(data):
    parts = data.split(';')
    for part in parts:
        if part.startswith('MN='):
            return part[3:]
    return None

# 发布数据到MQTT
def publish_to_mqtt(client_id, data):
    if client_id not in mqtt_clients:
        # 创建新的MQTT客户端实例
        client = mqtt.Client(client_id=client_id)
        client.username_pw_set(mqtt_username, mqtt_password)
        client.tls_set(ca_certs=None, certfile=None, keyfile=None, cert_reqs=ssl.CERT_NONE, tls_version=ssl.PROTOCOL_TLS, ciphers=None)
        client.tls_insecure_set(True)
        client.on_connect = on_connect        
        client.connect(mqtt_server, mqtt_port)
        # client.loop_start()
        mqtt_clients[client_id] = client
    else:
        client = mqtt_clients[client_id]

    client.publish(mqtt_topic, data)
    print(f"Data sent to MQTT by {client_id}: {data}")

# 启动TCP服务器
tcp_server_thread = threading.Thread(target=tcp_server)
tcp_server_thread.daemon = True
tcp_server_thread.start()

# 按需停止服务器
try:
    while True:
        time.sleep(1)
except KeyboardInterrupt:
    print("Exiting...")
    # 关闭所有MQTT客户端
    for client in mqtt_clients.values():
        client.loop_stop()
        client.disconnect()
    for client in tcpClientThreads:
        client.join()
    
    # 等待TCP服务器线程结束
    tcp_server_thread.join()
