import datetime
import time

from request_api import post_data

time_latest_transfer = datetime.datetime(2020, 1, 1, 0, 0, 0)
time_now = datetime.datetime.now()

while True:
    try:
        time_now = datetime.datetime.now()
        if time_now.minute != time_latest_transfer.minute \
                or time_now - time_latest_transfer >= datetime.timedelta(minutes=2):
            post_data(time_now)
            time_latest_transfer = time_now

        print(time_now)
        time.sleep(15)
    except Exception as e:
        print(e)
        time.sleep(15)
