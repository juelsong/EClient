import datetime


def print_instance(string, instance):
    print(string)
    print(type(instance))
    print(instance.args)
    print(instance)


def print_with_datetime_now(str_format, str_tuple=None):
    str_time = datetime.datetime.now().strftime('[%Y-%m-%d %H:%M:%S] ')
    if str_tuple:
        print((str_time + str_format) % str_tuple)
    else:
        print(str_time + str_format)

