
# 测试地址
broker_address = '47.117.118.169'
port = 18883
username = 'monitor_pole'
password = 'Monitor.2024#Pole'
topic = "monitor/pole/"

db_minute_data_table_name = 'monitor_minutedata'
db_base_device_table_name = 'monitor_device'
db_api_device_table_name = 'monitor_jiangongdevice'

# db_connect_command = \
#     'host=106.14.187.149 port=5432 dbname=longdi_dust user=na19high_ld password=na#fg_pg19'

db_connect_command = \
     'host=127.0.0.1 port=57702 dbname=longdi_dust user=na19high_ld password=na#fg_pg19'
