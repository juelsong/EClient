

def search_item_with_match_key_and_value(object_list, match_key, match_value, reverse=False):
    '''
    检索一个list中, match_key 的值 = value 的元素
    # TODO: 目前返回第一个匹配的元素,后期需要改进为:返回所有匹配的元素
    :param object_list: 被检索的列表对象
    :param match_key: 检索的key
    :param match_value: 检索的值
    :param reverse: True - object_list是依据match_key的降序列表, False - object_list是依据match_key的升序列表
    :return: 列表中找到的对象
    '''
    items_total = len(object_list)

    item_scan_start_index = 0
    item_scan_end_index = items_total - 1

    while True:
        if (item_scan_end_index - item_scan_start_index) >= 2:
            item_scan_index = item_scan_start_index + (item_scan_end_index - item_scan_start_index) // 2

            if object_list[item_scan_index][match_key] > match_value:
                if reverse:
                    item_scan_start_index = item_scan_index
                else:
                    item_scan_end_index = item_scan_index
            elif object_list[item_scan_index][match_key] < match_value:
                item_scan_start_index = item_scan_index
                if reverse:
                    item_scan_end_index = item_scan_index
                else:
                    item_scan_start_index = item_scan_index
            else:
                return object_list[item_scan_index]

        else:
            if len(object_list) == 0:
                return None

            if object_list[item_scan_start_index][match_key] == match_value:
                return object_list[item_scan_start_index]

            if object_list[item_scan_end_index][match_key] == match_value:
                return object_list[item_scan_end_index]

            return None
