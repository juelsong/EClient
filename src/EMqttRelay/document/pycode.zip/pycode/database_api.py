"""
2018-12-29 v1.0.2 修复了update接口功能不对的bug
2019-03-26 v1.0.3 增加了delete接口
2019-08-04 v1.0.4 增加了直接执行某command的接口
2020-04-29 v1.0.5 增加了database_select_fields_in_dict，需要查询的字段作为字典key传入
"""

import psycopg2
from error_message import print_instance


class DatabaseConnectResult:
    def __init__(self):
        self.is_connected = False
        self.connection = None


class DatabaseSelectResult:
    def __init__(self):
        self.is_success = False
        self.data_list = []


def database_connect(connect_string):
    '''

    :param connect_string: 连接指令
    :return:连接结果自定义类
    '''
    result = DatabaseConnectResult()

    try:
        con = psycopg2.connect(connect_string)
        result.is_connected = True
        result.connection = con
    except Exception as instance:
        print_instance('psycopg2 database connect failed', instance)

    return result


def database_disconnect(connection):
    '''

    :param connection: 一个已经连接上数据库的连接对象
    :return:
    '''
    result = DatabaseConnectResult()

    try:
        connection.close()
        result.is_connected = False
        result.connection = None
    except Exception as instance:
        print_instance('psycopg2 database disconnect failed', instance)

    return result


def database_update(connection, table_name, values_dict, condition_string, is_commit):
    '''

    :param connection: 有效的数据库连接
    :param table_name: 数据库表
    :param values_dict: 需要 UPDATE 的键和值
    :param condition_string: 查询条件
    :return: 返回 INSERT 结果 bool 类型
    '''
    result = False
    keys_string = ''
    values_string = ''

    dict_length = len(values_dict)

    if dict_length == 0:
        return result

    for key in values_dict.keys():
        keys_string += key

        if isinstance(values_dict[key], int) is True:
            values_string += key + "='" + str(values_dict[key]) + "'"
        elif isinstance(values_dict[key], float) is True:
            values_string += key + "='" + '%f' % values_dict[key] + "'"
        else:
            values_string += key + "='" + values_dict[key] + "'"

        if dict_length > 1:
            dict_length -= 1
            keys_string += ','
            values_string += ','

    try:
        command = r"UPDATE %s SET %s WHERE %s" % (table_name, values_string, condition_string)

        cursor = connection.cursor()
        cursor.execute(command)

        if is_commit:
            connection.commit()

        result = True
    except Exception as instance:
        print_instance('psycopg2 insert failed', instance)

    return result


def database_insert_into(connection, table_name, values_dict, is_commit):
    '''

    :param connection: 有效的数据库连接
    :param table_name: 数据库表
    :param values_dict: 需要 INSERT 的表内键和值
    :return: 返回 INSERT 结果 bool 类型
    '''
    result = False
    keys_string = ''
    values_string = ''

    dict_length = len(values_dict)

    for key in values_dict.keys():
        keys_string += key

        if isinstance(values_dict[key], int) is True:
            values_string += "'" + str(values_dict[key]) + "'"
        elif isinstance(values_dict[key], float) is True:
            values_string += "'" + '%f' % values_dict[key] + "'"
        else:
            values_string += "'" + values_dict[key] + "'"

        if dict_length > 1:
            dict_length -= 1
            keys_string += ','
            values_string += ','

    try:
        command = r"INSERT INTO %s (%s) VALUES (%s)" % (table_name, keys_string, values_string)

        cursor = connection.cursor()
        cursor.execute(command)

        if is_commit:
            connection.commit()

        result = True
    except Exception as instance:
        print_instance('psycopg2 insert failed', instance)

    return result


def database_select(connection, table_name, keys_string, condition_string):
    '''

    :param connection: 有效的数据库连接
    :param table_name: 数据库表
    :param keys_string: 需要 SELECT 的表内键值
    :param condition_string: 条件命令
    :return:返回一个 List 对象,即为查询结果
    '''
    result = DatabaseSelectResult()

    try:
        command = r"SELECT %s FROM %s %s" % (keys_string, table_name, condition_string)

        cursor = connection.cursor()
        cursor.execute(command)

        descriptions = cursor.description
        result.data_list = []
        for res in cursor.fetchall():
            row = {}
            for i in range(len(descriptions)):
                row[descriptions[i][0]] = res[i]
            result.data_list.append(row)

        result.is_success = True
    except Exception as instance:
        print_instance('psycopg2 select failed', instance)

    return result


def database_select_fields_in_list(connection, table_name, values_list=None, condition_string=''):
    """
    根据传入的字典键值查找数据, 字典为None则查询所有字段
    :param connection: 有效的数据库连接
    :param table_name: 数据库表
    :param values_dict: 需要 SELECT 的表内键值组成的字典
    :param condition_string: 条件命令
    :return:返回一个 List 对象,即为查询结果
    """
    result = DatabaseSelectResult()

    if values_list is not None:
        dict_length = len(values_list)

        keys_string = ''

        for key in values_list:
            keys_string += key

            if dict_length > 1:
                dict_length -= 1
                keys_string += ','
    else:
        keys_string = '*'

    try:
        command = r"SELECT %s FROM %s %s" % (keys_string, table_name, condition_string)

        cursor = connection.cursor()
        cursor.execute(command)

        descriptions = cursor.description
        result.data_list = []
        for res in cursor.fetchall():
            row = {}
            for i in range(len(descriptions)):
                row[descriptions[i][0]] = res[i]
            result.data_list.append(row)

        result.is_success = True
    except Exception as instance:
        print_instance('psycopg2 select failed', instance)

    return result


def database_delete(connection, table_name, condition_string, is_commit):
    result = DatabaseSelectResult()

    try:
        command = r"DELETE FROM %s WHERE %s" % (table_name, condition_string)

        cursor = connection.cursor()
        cursor.execute(command)

        if is_commit:
            connection.commit()

        result.is_success = True
    except Exception as instance:
        print_instance('psycopg2 insert failed', instance)

    return result


def database_run_command(connection, command):
    result = False

    try:
        cursor = connection.cursor()
        cursor.execute(command)
        result = True
    except Exception as instance:
        print_instance('psycopg2 insert failed', instance)

    return result
